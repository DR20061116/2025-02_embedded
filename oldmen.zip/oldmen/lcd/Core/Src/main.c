/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "Com_debug.h"
#include "Delay.h"
#include "jy901s.h"
#include "GPS.h"
#include "LORA.h"
#include "Buzzer.h"
#include "Int_led.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
uint8_t g_usart2_receivedata=0;
uint8_t rx_tmp;

char rxdatabufer;
uint16_t point1 = 0;
_SaveData Save_Data;
char UART3_GPS_BUF[UART3_GPS_LEN];



void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
		   uint8_t Res;
      static uint8_t uart3_rx_buf;
	
	    if(huart==&huart2 )
       {
       jy61p_ReceiveData (g_usart2_receivedata);
	     HAL_UART_Receive_IT(&huart2, &g_usart2_receivedata, 1); 
       }	
	     
			 
			 
			 
			  if(huart->Instance == USART3)  
    {
         Res = uart3_rx_buf;  
        if(Res == '$')  
        {
          point1 = 0;	
        }
      UART3_GPS_BUF[point1++] = Res;
     if(UART3_GPS_BUF[0] == '$' && UART3_GPS_BUF[4] == 'M' && UART3_GPS_BUF[5] == 'C')
    {
        if(Res == '\n')  
      {
        memset(Save_Data.GPS_Buffer, 0, GPS_Buffer_Length);
        memcpy(Save_Data.GPS_Buffer, UART3_GPS_BUF, point1);
        Save_Data.isGetData = true;
        point1 = 0;
        memset(UART3_GPS_BUF, 0, UART3_GPS_LEN);
      }			
     }
         if(point1 >= UART3_GPS_LEN)
         {
            point1 = UART3_GPS_LEN;    
           }
         HAL_UART_Receive_IT(&huart3, &uart3_rx_buf, 1);
    }  
		
	
	
	
	
	
}





/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_USART3_UART_Init();
  MX_UART4_Init();
  /* USER CODE BEGIN 2 */
		
//1.Log output & print
//     debug_printf("hello world");

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	 Delay_Init();
   HAL_UART_Receive_IT(&huart2, &g_usart2_receivedata, 1);	 
   HAL_UART_Receive_IT(&huart3, &rx_tmp, 1);
	 
//2.LORA_Send	 
//	 	LORA[0]=0x05;
//	  LORA[1]=0x02;
//	  LORA[2]=0x03;
//	  LORA[3]=0x04;
//	  Serial_LORA();
  while (1)
  {
		
//3.JY901S
//      debug_printf("Roll:\n%f", Roll);
//		  debug_printf("Pitch:\n%f", Pitch);
//		  debug_printf("Yaw:\n%f", Yaw);
//			debug_printf("AccX:\n%f", AccX);
//		  debug_printf("AccY:\n%f", AccY);
//		  debug_printf("AccZ:\n%f", AccZ);
		
//4.GPS		
//		parseGpsBuffer();      
//    ShowGpsBuffer(); 
//		
		
//5.Buzzer
//		Buzzer_Start();
//		Buzzer_Stop();
 
//6.LED
//    Int_led_rainbow(20);
//		Int_led_blink(LED_RED, 1000);

//7.SU-03T




    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		HAL_Delay(100);
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
