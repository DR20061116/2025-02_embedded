#include "GPS.h"


void errorLog(int num)
{
	
	while (1)
	{
	  debug_printf("ERROR%d\r\n",num);
	}
}

void parseGpsBuffer()    //����
{
	char *subString;
	char *subStringNext;
	char i = 0;
	if (Save_Data.isGetData)    
	{
		Save_Data.isGetData = false;
//		printf("**************\r\n");
//		printf(Save_Data.GPS_Buffer);    //ԭ�����
		for (i = 0 ; i <= 6 ; i++)
		{
			if (i == 0)
			{
				if ((subString = strstr(Save_Data.GPS_Buffer, ",")) == NULL)    
					errorLog(1);	//��������
			}
			else
			{
				subString++;   //��һ��','�ĵ�ַ
				if ((subStringNext = strstr(subString, ",")) != NULL)//���ϴζ��ŵĵط���ʼ��
				{
					char usefullBuffer[2]; 
					switch(i)
					{
						case 1:memcpy(Save_Data.UTCTime, subString, subStringNext - subString);break;	//��ȡUTCʱ��
						case 2:memcpy(usefullBuffer, subString, subStringNext - subString);break;	    //��ȡUTCʱ��
						case 3:memcpy(Save_Data.latitude, subString, subStringNext - subString);break;	//��ȡγ����Ϣ
						case 4:memcpy(Save_Data.N_S, subString, subStringNext - subString);break;	    //��ȡN/S
						case 5:memcpy(Save_Data.longitude, subString, subStringNext - subString);break;	//��ȡ������Ϣ
						case 6:memcpy(Save_Data.E_W, subString, subStringNext - subString);break;	    //��ȡE/W

						default:break;
					}
					subString = subStringNext;
					Save_Data.isParseData = true;
					if(usefullBuffer[0] == 'A')
						Save_Data.isUsefull = true;
					else if(usefullBuffer[0] == 'V')
						Save_Data.isUsefull = false;
				}
				else
				{
					errorLog(2);	//��������
				}
			}
		}
	}
}


void ShowGpsBuffer()
{
	if (Save_Data.isParseData)
	{
		Save_Data.isParseData = false;

		if(Save_Data.isUsefull)
		{
			
			Save_Data.isUsefull = false;

			double num = atof(Save_Data.latitude);
      debug_printf("γ��: %.6f %s\r\n", num/100, Save_Data.N_S);

      double num1 = atof(Save_Data.longitude);
      debug_printf("����: %.6f %s\r\n", num1/100, Save_Data.E_W);
		}
		else
		{
			debug_printf("error");
		}
		
	}
}























