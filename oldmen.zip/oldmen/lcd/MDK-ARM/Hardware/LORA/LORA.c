#include "LORA.h"

uint8_t LORA[4];

void Serial_LORA(void)
{
    uint8_t send_buf[6] = {0};   
    send_buf[0] = 0xFF;          
    send_buf[1] = LORA[0];
    send_buf[2] = LORA[1];
    send_buf[3] = LORA[2];
    send_buf[4] = LORA[3];
    send_buf[5] = 0xFE;          
    HAL_UART_Transmit(&huart4, send_buf, 6, 100);
}




