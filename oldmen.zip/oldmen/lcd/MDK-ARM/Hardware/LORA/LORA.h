#ifndef __LORA_H
#define __LORA_H
#include "stm32f4xx_hal.h"
#include "usart.h"

extern uint8_t LORA[];


void Serial_LORA(void);

#endif 
