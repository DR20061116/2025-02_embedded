#ifndef __ADC_H
#define __ADC_H	
#include "stm32f10x.h"
#include "stm32f10x_adc.h"	  
   
void Adc_Init(void);
u16 Get_Adc(u8 ch);

#endif 
