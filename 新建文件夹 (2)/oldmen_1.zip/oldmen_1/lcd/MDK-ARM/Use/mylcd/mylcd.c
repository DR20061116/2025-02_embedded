#include "mylcd.h"
#include "pic.h"

void normal(void)
{
	       
        LCD_Fill(0, 0, LCD_W, LCD_H, WHITE);
	
        LCD_ShowPicture(149,4,11,8,gImage_wifi);
        LCD_ShowPicture(128,4,16,8,gImage_h); 	
	      LCD_DrawLine(0,16,160,16,RED);
//	      LCD_ShowPicture(0,90,14,18,gImage_position);
	
	
	      LCD_Fill(0,112,160,128,LIGHTBLUE);
	      LCD_ShowChinese(10,112,"�����½󣬰����ճ�",WHITE,WHITE,16,1);
	
	      LCD_DrawRectangle(0,30,32,49,BLACK);
	      LCD_ShowChinese(0,32,"����",BLACK,WHITE,16,1);
	      LCD_DrawRectangle(0,49,32,68,BLACK);
	      LCD_ShowChinese(0,51,"����",BLACK,WHITE,16,1);
	      LCD_DrawRectangle(0,68,32,87,BLACK);
	      LCD_ShowChinese(0,70,"���",BLACK,WHITE,16,1);
	      //LCD_ShowChinese(73,70,"��",BLACK,WHITE,16,1);
	      LCD_ShowChinese(33,51,"�Ϸ�",BLACK,WHITE,16,1);
	      LCD_ShowChinese(33,30,"����",BLACK,WHITE,16,1);
	
	
	      LCD_ShowPicture(66,20,32,26,gImage_xinlv);
				LCD_ShowString(98,20,"spo2:",RED,WHITE,16,1);
				LCD_ShowString(98,36,"rate:",RED,WHITE,16,1);
				
				
				 LCD_ShowPicture(75,51,23,40,gImage_medine);
				 LCD_ShowChinese(98,56,"�óԵ�ҩ",BLACK,WHITE,16,1);

				 
				
}

void Fall_Blink_Icon(void) {
    static uint32_t last_blink = 0;
    static uint8_t icon_visible = 0;

    // ÿ 500ms �л�һ��״̬��������ÿ�д��붼ˢ
    if (HAL_GetTick() - last_blink > 500) {
        last_blink = HAL_GetTick();
        
        if (icon_visible) {
            // �����׿��ͼ����ס��ģ��Ϩ��
            LCD_Fill(66, 20, 66+32, 20+26, WHITE); 
            icon_visible = 0;
        } else {
            // ����ͼ��
            LCD_ShowPicture(66, 20, 32, 26, gImage_xinlv);
            icon_visible = 1;
        }
    }
}


// ����Щ���ơ���һ����ʾ����������Ϊȫ�ֱ��������㸴λ
uint8_t fall_screen_init_flag = 0; 
uint8_t lock_med_a = 0;
uint8_t lock_med_b = 0;
uint8_t lock_med_c = 0;
uint8_t lock_med_d = 0;
uint8_t lock_med_e = 0;

void Fall(void)
{      
    // �ı��ж������������ 0 ����е�һ������ˢ��
    if(fall_screen_init_flag == 0)
    {
        LCD_Fill(0, 0, LCD_W, LCD_H, WHITE);
        LCD_ShowPicture(10,50,19,20,gImage_home); 
        LCD_ShowPicture(10,100,20,20,gImage_phone); 
        LCD_ShowChinese(29,55,"סַ",BLACK,WHITE,16,1);
        LCD_ShowChinese(29,100,"�绰",BLACK,WHITE,16,1);
        LCD_ShowString(61,100,":12345678",BLUE,WHITE,16,0);
        LCD_ShowString(61,55,":XX",BLUE,WHITE,16,0);
        LCD_ShowChinese(85,55,"��",BLUE,WHITE,16,1);
        LCD_ShowString(101,55,"XX",BLUE,WHITE,16,0);
        LCD_ShowChinese(115,55,"С��",BLUE,WHITE,16,1);
        LCD_ShowString(147,55,"X",BLUE,WHITE,16,0);
        
        fall_screen_init_flag = 1; // ����Ѿ���ʼ����
    }
    Fall_Blink_Icon();
}

void med_a(void)
{
    if(lock_med_a == 0)
    {
        LCD_Fill(108, 72, 156, 72 + 16, WHITE); 
        LCD_ShowChinese(108, 72, "ҩ��", BLACK, WHITE, 16, 1);
        LCD_ShowString(140, 72, "A", BLACK, WHITE, 16, 0);
        lock_med_a = 1;
    }
}

// med_b, med_c, med_d, med_e ͬ���޸ģ�
// �Ѻ����ڲ��� static int lock_med_x = 0; ȫ��ɾ������Ϊ�����Ѿ�������ȫ�ֱ�����
void med_b(void) {
    if(lock_med_b == 0) {
        LCD_Fill(108, 72, 156, 72 + 16, WHITE); 
        LCD_ShowChinese(108, 72, "ҩ��", BLACK, WHITE, 16, 1);
        LCD_ShowString(140, 72, "B", BLACK, WHITE, 16, 0);
        lock_med_b = 1;
    }
}
void med_c(void) {
    if(lock_med_c == 0) { LCD_Fill(108, 72, 156, 72 + 16, WHITE); LCD_ShowChinese(108, 72, "ҩ��", BLACK, WHITE, 16, 1); LCD_ShowString(140, 72, "C", BLACK, WHITE, 16, 0); lock_med_c = 1; }
}
void med_d(void) {
    if(lock_med_d == 0) { LCD_Fill(108, 72, 156, 72 + 16, WHITE); LCD_ShowChinese(108, 72, "ҩ��", BLACK, WHITE, 16, 1); LCD_ShowString(140, 72, "D", BLACK, WHITE, 16, 0); lock_med_d = 1; }
}
void med_e(void) {
    if(lock_med_e == 0) { LCD_Fill(108, 72, 156, 72 + 16, WHITE); LCD_ShowChinese(108, 72, "ҩ��", BLACK, WHITE, 16, 1); LCD_ShowString(140, 72, "E", BLACK, WHITE, 16, 0); lock_med_e = 1; }
}
